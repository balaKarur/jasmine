import './throws.mjs';

it('a spec', () => {});
