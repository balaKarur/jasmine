for (let i = 1; i <= 5; i++) {
  it('spec 1', function() {
    console.log('in spec ' + i);
  });
}
