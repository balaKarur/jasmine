export function foo() {
  return 42;
}
