global.require_tester_was_loaded = true;
module.exports = {};
