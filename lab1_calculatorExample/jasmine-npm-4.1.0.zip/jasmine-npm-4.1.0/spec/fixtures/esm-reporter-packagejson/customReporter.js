export default function Reporter() {}

Reporter.prototype.jasmineDone = function() {
    console.log('customReporter.js jasmineDone');
};
