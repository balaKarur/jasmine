if (!module.parent) {
  throw new Error('aRequire.js was loaded as an ES module');
}
